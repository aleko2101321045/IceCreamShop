
public interface IceCream {
    String getDescription();
    double cost();
}