
public interface ConsumptionStrategy {
    void consume();
}
