
public class StrawberryIceCream implements IceCream {
    @Override
    public String getDescription() {
        return "Ягодов сладолед";
    }

    @Override
    public double cost() {
        return 1.80;
    }
}