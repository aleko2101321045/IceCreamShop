
public class AtTheParkStrategy implements ConsumptionStrategy {
    @Override
    public void consume() {
        System.out.println("Консумирате сладоледа в парка.");
    }
}
