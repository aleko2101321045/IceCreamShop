
public class AtTheBeachStrategy implements ConsumptionStrategy {
    @Override
    public void consume() {
        System.out.println("Консумирате сладоледа на плажа.");
    }
}