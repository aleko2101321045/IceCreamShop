
public class AtHomeStrategy implements ConsumptionStrategy {
    @Override
    public void consume() {
        System.out.println("Консумирате сладоледа вкъщи.");
    }
}
